
class V0:
    # Takes in a list of words and stores them in a hash table
    def __init__(self, words):
        self.words = words
        self.hash_table = {}

        for word in self.words:
            key = word[0] 

            if key in self.hash_table:
                if word not in self.hash_table[key]:
                    self.hash_table[key].append(word)
            else:
                self.hash_table[key] = self.hash_table.setdefault(key, [word])

    # Takes in a file and writes to a new file
    # Whenever a "key word" is found, the file gets broken into a new line
    def segment_by_words (self, filename):
        with open(filename, 'r') as file:
            content = file.read()
            words = content.split()
            modified_content = []

            for word in words:
                key = word[0]

                if key in self.hash_table:
                    if word in self.hash_table[key]:
                        modified_content.append('\n' + word)
                    else:
                        modified_content.append(word)

            modified_text = ' '.join(modified_content)

            with open('modified_' + filename, 'w') as file:
                file.write(modified_text)


    def get_hash_table(self):
        return self.hash_table

# Example usage
words = ["apple", "banana", "berry", "carrot", "cherry"]
tester = V0(words)

print(tester.get_hash_table())  # Output: {'apple': 0, 'banana': 1, 'cherry': 2}
tester.segment_by_words("test_file.txt")
